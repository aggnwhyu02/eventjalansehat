
JOGGING EVENT SYSTEM

FITUR:
- Login peserta
- Tracking GPS realtime
- Ranking
- Monitoring peserta
- Live dashboard
- Tracking jalur Google Maps

CARA MENJALANKAN

BACKEND
cd backend
npm install express socket.io cors
node server.js

FRONTEND
cd frontend
npm install
npm run dev
