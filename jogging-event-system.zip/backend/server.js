
const express = require('express')
const http = require('http')
const { Server } = require('socket.io')
const cors = require('cors')

const app = express()
const server = http.createServer(app)

const io = new Server(server, {
  cors: {
    origin: '*'
  }
})

app.use(cors())

let participants = []

io.on('connection', (socket) => {

  socket.on('join-event', (data) => {

    participants.push({
      id: socket.id,
      name: data.name,
      status: 'running'
    })

    io.emit('participants-update', participants)
  })

  socket.on('location-update', (data) => {
    console.log(data)
  })

  socket.on('disconnect', () => {
    participants = participants.filter(
      p => p.id !== socket.id
    )

    io.emit('participants-update', participants)
  })
})

server.listen(5000, () => {
  console.log('Server running on port 5000')
})
