
import { useEffect, useState } from 'react'
import io from 'socket.io-client'

const socket = io('http://localhost:5000')

export default function App() {
  const [name, setName] = useState('')
  const [joined, setJoined] = useState(false)
  const [participants, setParticipants] = useState([])

  useEffect(() => {
    socket.on('participants-update', (data) => {
      setParticipants(data)
    })
  }, [])

  const joinEvent = () => {
    socket.emit('join-event', { name })
    setJoined(true)

    navigator.geolocation.watchPosition((position) => {
      socket.emit('location-update', {
        latitude: position.coords.latitude,
        longitude: position.coords.longitude
      })
    })
  }

  if (!joined) {
    return (
      <div style={{padding:20}}>
        <h1>EVENT JOGGING SFA</h1>
        <input
          placeholder="Masukkan Nama"
          value={name}
          onChange={(e)=>setName(e.target.value)}
        />
        <button onClick={joinEvent}>Masuk Event</button>
      </div>
    )
  }

  return (
    <div style={{padding:20}}>
      <h1>LIVE TRACKING EVENT</h1>

      <h2>Peserta</h2>

      {participants.map((p)=>(
        <div key={p.id}>
          {p.name} - {p.status}
        </div>
      ))}
    </div>
  )
}
